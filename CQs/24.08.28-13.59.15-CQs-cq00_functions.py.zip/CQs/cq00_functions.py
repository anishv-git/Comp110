"""My First Mimicry Function"""

__author__ = "730773852"


def mimic(message: str) -> str:
    return message


def main() -> None:
    """to print mimic"""


if __name__ == "__main__":
    main()
print(mimic(message=input("What is your message?")))
