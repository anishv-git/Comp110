"""While loops challenge question"""


def num_instances(phrase: str, search_char: str):
    count = 0
    index = 0

    while index <= len(phrase) - len(search_char):
        match = True
        sub_index = 0

        while sub_index < len(search_char):
            if phrase[index + sub_index] != search_char[sub_index]:
                match = False
            sub_index += 1

        if match == True:
            count += 1
            index += len(search_char)

        else:
            index += 1

    print(count)


num_instances("HelloHelloHello", "e")
