"""My first exercise in COMP110!"""

__author__ = "730773852"


def greet(name: str) -> str:
    """A welcoming first function definition."""
    return "Hello, " + name + "!"
