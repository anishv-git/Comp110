"""Practice with Conditionals, Local Variables, and User Input"""

__author__ = "730773852"


def guess_a_number():

    guess_a_number = int(input("Guess a number: "))
    print("Your guess was: " + str(guess_a_number))

    secret = 7

    if guess_a_number == secret:
        print("You got it!")
    elif guess_a_number < secret:
        print("Your guess was too low! The secret number is " + str(secret))
    else:
        print("Your guess was too high! The secret number is " + str(secret))


if __name__ == "__main__":
    guess_a_number()
